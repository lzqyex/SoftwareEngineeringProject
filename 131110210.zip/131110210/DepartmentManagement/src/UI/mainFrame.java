package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import model.Documents;
import Class.MainFrameClass;

import javax.swing.JButton;

public class mainFrame extends JFrame {

	private JPanel contentPane;
	private JTable table;
	
	static mainFrame frame;
	
	JButton btn1;
	JButton btn2;
	
	String userID;
	int type;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	private mainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 43, 414, 175);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		btn1 = new JButton("New button");
		btn1.setBounds(228, 228, 93, 23);
		contentPane.add(btn1);
		
		btn2 = new JButton("New button");
		btn2.setBounds(331, 228, 93, 23);
		contentPane.add(btn2);
	}
	
	public mainFrame(int type,final String userID){
		this();
		this.type = type;
		this.userID = userID;
		
		if(type == 1){
			removeButtonMouseListeners(btn1);
			removeButtonMouseListeners(btn2);
			btn1.setVisible(false);
			btn2.setVisible(true);
			btn2.setText("�鿴ͳ��");
			btn2.addMouseListener(new MouseListener(){
				public void mouseClicked(MouseEvent e) {
					CountFrame.frame.updateTable();
					CountFrame.frame.show();
					mainFrame.frame.dispose();
				}
				public void mousePressed(MouseEvent e) {}
				public void mouseReleased(MouseEvent e) {}
				public void mouseEntered(MouseEvent e) {}
				public void mouseExited(MouseEvent e) {}
			});
		}
		else if(type == 2){
			removeButtonMouseListeners(btn1);
			removeButtonMouseListeners(btn2);
			btn1.setVisible(true);
			btn2.setVisible(true);
			btn1.setText("�������");
			btn2.setText("�˳�");
			btn1.addMouseListener(new MouseListener(){
				public void mouseClicked(MouseEvent e) {
					int i = table.getSelectedRow();
					if(i == -1){
						JOptionPane.showMessageDialog(null, "��ѡ��һ����Ϣ��", "����", JOptionPane.ERROR_MESSAGE);
						return;
					}
					MainFrameClass mainframeclass = new MainFrameClass();
					mainframeclass.repairedOver(table.getValueAt(i, 0).toString());
					JOptionPane.showMessageDialog(null, "�ύ�ɹ���", "��Ϣ", JOptionPane.INFORMATION_MESSAGE);
					updateTable();
				}
				public void mousePressed(MouseEvent e) {}
				public void mouseReleased(MouseEvent e) {}
				public void mouseEntered(MouseEvent e) {}
				public void mouseExited(MouseEvent e) {}
			});
			btn2.addMouseListener(new MouseListener(){
				public void mouseClicked(MouseEvent e) {
					System.exit(0);
				}
				public void mousePressed(MouseEvent e) {}
				public void mouseReleased(MouseEvent e) {}
				public void mouseEntered(MouseEvent e) {}
				public void mouseExited(MouseEvent e) {}
			});
		}
		else{
			removeButtonMouseListeners(btn1);
			removeButtonMouseListeners(btn2);
			btn1.setVisible(true);
			btn2.setVisible(true);
			btn1.setText("����ά��");
			btn2.setText("�˳�");
			btn1.addMouseListener(new MouseListener(){
				public void mouseClicked(MouseEvent e) {
					faultRepair.frame.studentId = userID;
					faultRepair.frame.show();
					mainFrame.frame.dispose();
				}
				public void mousePressed(MouseEvent e) {}
				public void mouseReleased(MouseEvent e) {}
				public void mouseEntered(MouseEvent e) {}
				public void mouseExited(MouseEvent e) {}
			});
			btn2.addMouseListener(new MouseListener(){
				public void mouseClicked(MouseEvent e) {
					System.exit(0);
				}
				public void mousePressed(MouseEvent e) {}
				public void mouseReleased(MouseEvent e) {}
				public void mouseEntered(MouseEvent e) {}
				public void mouseExited(MouseEvent e) {}
			});
		}
		
		updateTable();
	}
	
	public void updateTable(){
		MainFrameClass mfc = new MainFrameClass();
		final DefaultTableModel dtm = (DefaultTableModel) table.getModel();
		dtm.setRowCount(0);
		dtm.setColumnIdentifiers(new String[]{"���","����ѧ��","������Ա","���˵��","����״̬"});
		Vector vector;
		if(type == 1){
			//����Ա���ݵ�¼
			List list = mfc.getAllDocuments();
			for(int i = 0;i < list.size(); i++){
				vector = new Vector();
				vector.add(((Documents)list.get(i)).getDocumentsId());
				vector.add(mfc.getStudentByStudentID(((Documents)list.get(i)).getStudentId()).getStudentName());
				
				if(((Documents)list.get(i)).getEmployeeId() == null || ((Documents)list.get(i)).getEmployeeId() == "")
					vector.add("");
				else
					vector.add(mfc.getEmployeeByEmployeeID(((Documents)list.get(i)).getEmployeeId()).getEmployeeName());
				
				vector.add(((Documents)list.get(i)).getDocumentsMessage());
				vector.add(((Documents)list.get(i)).getDocumentsState());
				
				dtm.addRow(vector);
			}
		}
		else if(type == 2){
			//ά�޹����ݵ�¼
			List list = mfc.getDocumentsByEmployeeID(userID);
			for(int i = 0;i < list.size(); i++){
				vector = new Vector();
				vector.add(((Documents)list.get(i)).getDocumentsId());
				vector.add(mfc.getStudentByStudentID(((Documents)list.get(i)).getStudentId()).getStudentName());
				
				if(((Documents)list.get(i)).getEmployeeId() == null || ((Documents)list.get(i)).getEmployeeId() == "")
					vector.add("");
				else
					vector.add(mfc.getEmployeeByEmployeeID(((Documents)list.get(i)).getEmployeeId()).getEmployeeName());
				
				vector.add(((Documents)list.get(i)).getDocumentsMessage());
				vector.add(((Documents)list.get(i)).getDocumentsState());
				
				dtm.addRow(vector);
			}
		}
		else{
			//ѧ�����ݵ�¼
			List list = mfc.getDocumentsByStudentID(userID);		
			for(int i = 0;i < list.size(); i++){
				vector = new Vector();
				vector.add(((Documents)list.get(i)).getDocumentsId());
				vector.add(mfc.getStudentByStudentID(((Documents)list.get(i)).getStudentId()).getStudentName());
				
				if(((Documents)list.get(i)).getEmployeeId() == null || ((Documents)list.get(i)).getEmployeeId() == "")
					vector.add("");
				else
					vector.add(mfc.getEmployeeByEmployeeID(((Documents)list.get(i)).getEmployeeId()).getEmployeeName());
				
				vector.add(((Documents)list.get(i)).getDocumentsMessage());
				vector.add(((Documents)list.get(i)).getDocumentsState());
				
				dtm.addRow(vector);
			}
		}
	}
	
	public void removeButtonMouseListeners(JButton jbutton){
		MouseListener[] m = jbutton.getMouseListeners();
		for(int i = 0; i < m.length ; i++){
			jbutton.removeMouseListener(m[i]);
		}
	}
}
