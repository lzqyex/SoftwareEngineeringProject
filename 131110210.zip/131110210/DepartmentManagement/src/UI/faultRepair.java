package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;

import Class.UID;
import Class.faultRepairClass;
import model.Documents;
import javax.swing.JTextArea;

public class faultRepair extends JFrame {

	private JPanel contentPane;

	JTextArea textArea;
	
	static String studentId = new String();
	static faultRepair frame = new faultRepair();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public faultRepair() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 360, 283);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textArea = new JTextArea();
		textArea.setBounds(10, 51, 324, 139);
		contentPane.add(textArea);
		
		JButton confirmButton = new JButton("\u63D0\u4EA4");
		confirmButton.setBounds(121, 211, 93, 23);
		confirmButton.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				Documents d = new Documents();
				d.setDocumentsId(String.valueOf(UID.next()));
				d.setDocumentsMessage(textArea.getText());
				d.setDocumentsState("������");
				d.setStudentId(studentId);
				
				faultRepairClass frc = new faultRepairClass();
				frc.addNewDocuments(d);
				JOptionPane.showMessageDialog(null, "�ύ�ɹ���", "��Ϣ", JOptionPane.INFORMATION_MESSAGE);
				
				faultRepair.frame.dispose();
				mainFrame.frame.updateTable();
				mainFrame.frame.show();
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
		});
		contentPane.add(confirmButton);
		
		JButton cancelButton = new JButton("\u53D6\u6D88");
		cancelButton.setBounds(241, 211, 93, 23);
		cancelButton.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				faultRepair.frame.dispose();
				mainFrame.frame.show();
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
		});
		contentPane.add(cancelButton);
		
		JLabel label = new JLabel("\u8BF7\u586B\u5199\u8BE6\u7EC6\u4FE1\u606F");
		label.setBounds(10, 29, 112, 23);
		contentPane.add(label);
	}
}
