package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import model.Employee;
import Class.AddEmployeeFrameClass;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class AddEmployeeFrame extends JFrame {

	private JPanel contentPane;
	private JTextField numberTextField;
	private JTextField nameTextField;
	private JTextField keyTextField;
	
	static AddEmployeeFrame frame = new AddEmployeeFrame();
	private JTextField phoneTextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddEmployeeFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 273, 280);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u7F16\u53F7");
		label.setBounds(27, 41, 54, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setBounds(27, 71, 54, 15);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u767B\u5F55\u5BC6\u7801");
		label_2.setBounds(27, 131, 54, 15);
		contentPane.add(label_2);
		
		numberTextField = new JTextField();
		numberTextField.setBounds(91, 38, 87, 18);
		contentPane.add(numberTextField);
		numberTextField.setColumns(10);
		
		nameTextField = new JTextField();
		nameTextField.setBounds(91, 71, 87, 18);
		contentPane.add(nameTextField);
		nameTextField.setColumns(10);
		
		keyTextField = new JTextField();
		keyTextField.setBounds(91, 131, 87, 18);
		contentPane.add(keyTextField);
		keyTextField.setColumns(10);
		
		JButton confirmButton = new JButton("\u786E\u5B9A");
		confirmButton.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				AddEmployeeFrameClass aefc = new AddEmployeeFrameClass();
				if(aefc.isEmployeeIdExist(numberTextField.getText())){
					JOptionPane.showMessageDialog(null, "����Ѵ��ڣ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				Employee e1 = new Employee();
				e1.setEmployeeId(numberTextField.getText());
				e1.setEmployeeName(nameTextField.getText());
				e1.setEmployeePhone(phoneTextField.getText());
				e1.setKey(keyTextField.getText());
				aefc.addNewEmployee(e1);
				JOptionPane.showMessageDialog(null, "���ӳɹ���", "��Ϣ", JOptionPane.INFORMATION_MESSAGE);
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
		});
		confirmButton.setBounds(78, 208, 74, 23);
		contentPane.add(confirmButton);
		
		JButton cancelButton = new JButton("\u53D6\u6D88");
		cancelButton.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				CountFrame.frame.updateTable();
				CountFrame.frame.show();
				AddEmployeeFrame.frame.dispose();
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
		});
		cancelButton.setBounds(173, 208, 74, 23);
		contentPane.add(cancelButton);
		
		JLabel label_3 = new JLabel("\u7535\u8BDD");
		label_3.setBounds(27, 101, 54, 15);
		contentPane.add(label_3);
		
		phoneTextField = new JTextField();
		phoneTextField.setBounds(91, 101, 87, 21);
		contentPane.add(phoneTextField);
		phoneTextField.setColumns(10);
	}
}
