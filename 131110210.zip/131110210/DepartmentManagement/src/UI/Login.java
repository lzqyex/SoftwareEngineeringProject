package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import Class.LoginClass;
import javax.swing.JPasswordField;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField usernameTextField;

	static Login frame = new Login();
	private JPasswordField passwordField;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 288, 252);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u7528\u6237\u540D");
		lblNewLabel.setBounds(44, 61, 54, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5BC6\u7801");
		lblNewLabel_1.setBounds(44, 113, 54, 15);
		contentPane.add(lblNewLabel_1);
		
		usernameTextField = new JTextField();
		usernameTextField.setBounds(108, 58, 99, 18);
		contentPane.add(usernameTextField);
		usernameTextField.setColumns(10);
		
		JButton button = new JButton("\u786E\u8BA4");
		button.setBounds(86, 166, 93, 23);
		button.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				String userId = usernameTextField.getText();
				String password = passwordField.getText();
				LoginClass lc = new LoginClass();
				int i = lc.check(userId, password);
				if(-1 == i){
					JOptionPane.showMessageDialog(null, "�û����������", "����", JOptionPane.ERROR_MESSAGE);
				    return;
				}
				mainFrame.frame = new mainFrame(i,userId);
				mainFrame.frame.show();
				frame.dispose();
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
		});
		contentPane.add(button);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(108, 110, 99, 23);
		contentPane.add(passwordField);
	}
}
