package UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;

import model.Employee;
import Class.CountFrameClass;

public class CountFrame extends JFrame {

	private JPanel contentPane;
	private JTable table;

	static CountFrame frame = new CountFrame();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CountFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 43, 414, 151);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("\u5168\u90E8\u5DE5\u4EBA\u5DE5\u4F5C\u60C5\u51B5\u5982\u4E0B\uFF1A");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 10, 193, 23);
		contentPane.add(lblNewLabel);
		
		JButton addEmployeeButton = new JButton("\u589E\u52A0\u5DE5\u4EBA");
		addEmployeeButton.setBounds(125, 228, 93, 23);
		addEmployeeButton.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				CountFrame.frame.dispose();
				AddEmployeeFrame.frame.show();
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
		});
		contentPane.add(addEmployeeButton);
		
		JButton fireEmployeeButton = new JButton("\u5220\u9664\u5DE5\u4EBA");
		fireEmployeeButton.setBounds(228, 228, 93, 23);
		fireEmployeeButton.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				if(-1 == table.getSelectedRow()){
					JOptionPane.showMessageDialog(null, "��ѡ��һ����Ϣ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
                int i = JOptionPane.showConfirmDialog( null , "ȷ��ɾ������Ԥ����Ϣ��" , "ȷ��", JOptionPane.YES_NO_OPTION ) ;
				
				switch(i){
				    case -1:
					    //�û��ر�����ʾ��û���κβ���
				    	break;
				    case 0:
				    	//�û�ȷ����ɾ������
				    	String employeeID = (String) table.getValueAt(table.getSelectedRow(), 0);
				    	CountFrameClass cfc = new CountFrameClass();
				    	cfc.deleteEmployee(employeeID);
				    	updateTable();
				    	JOptionPane.showMessageDialog(null, "ɾ���ɹ���", "��Ϣ", JOptionPane.INFORMATION_MESSAGE);
				    	break;
				    case 1:
				        //�û�ȡ����ɾ������
				    	break;
				}
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
		});
		contentPane.add(fireEmployeeButton);
		
		JButton existButton = new JButton("\u9000\u51FA");
		existButton.setBounds(331, 228, 93, 23);
		existButton.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent e) {
				CountFrame.frame.dispose();
				mainFrame.frame.show();
			}
			public void mousePressed(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
			public void mouseEntered(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {}
		});
		contentPane.add(existButton);
		
		updateTable();
	}
	
	public void updateTable(){
		CountFrameClass cfc = new CountFrameClass();
		final DefaultTableModel dtm = (DefaultTableModel) table.getModel();
		dtm.setRowCount(0);
		dtm.setColumnIdentifiers(new String[]{"���˱��","����","���������","������ϵȴ�ȷ����","��ϵ��ʽ"});
		List list = cfc.getAllEmployee();
		Vector vector;
		for(int i = 0 ; i < list.size() ; i++){
			vector = new Vector();
			vector.add(((Employee)list.get(i)).getEmployeeId());
			vector.add(((Employee)list.get(i)).getEmployeeName());
			cfc.countMessage(vector);
			vector.add(((Employee)list.get(i)).getEmployeePhone());
			
			dtm.addRow(vector);
		}
	}
}
