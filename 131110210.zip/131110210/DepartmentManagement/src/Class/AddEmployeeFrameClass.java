package Class;

import org.hibernate.Session;

import model.Employee;
import dao.EmployeeDAO;
import factory.HibernateSessionFactory;

public class AddEmployeeFrameClass {

	public Boolean isEmployeeIdExist(String employeeId){
		EmployeeDAO employeedao = new EmployeeDAO();
		Employee employee = employeedao.findById(employeeId);
		if(employee == null)
			return false;
		else 
			return true;
	}

	public void addNewEmployee(Employee e) {
		Session session;
		session = HibernateSessionFactory.getSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		session.save(e);
		tx.commit();
		session.close();
	}
	
}
