package Class;

import model.Employee;
import model.Student;
import dao.EmployeeDAO;
import dao.StudentDAO;

public class LoginClass {

	public int check(String username,String password){
		if(username.equals("admin") && password.equals("admin"))
			return 1;
		EmployeeDAO employeedao = new EmployeeDAO();
		Employee e = employeedao.findById(username);
		StudentDAO studentdao = new StudentDAO();
		Student s = studentdao.findById(username);
		
		if(e != null && e.getKey().equals(password))
			return 2;
		if(s != null && s.getKey().equals(password))
			return 3;
		
		return -1;
	}
	
}
