package Class;

import org.hibernate.Session;

import dao.DocumentsDAO;
import factory.HibernateSessionFactory;
import model.Documents;

public class faultRepairClass {

	public void addNewDocuments(Documents d){
		Session session;
		session = HibernateSessionFactory.getSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		session.save(d);
		tx.commit();
		session.close();
	}
	
}
