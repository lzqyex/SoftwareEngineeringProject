package Class;

import java.util.List;

import org.hibernate.Session;

import model.Documents;
import model.Employee;
import model.Student;
import dao.DocumentsDAO;
import dao.EmployeeDAO;
import dao.StudentDAO;
import factory.HibernateSessionFactory;

public class MainFrameClass {

	public List getAllDocuments(){
		DocumentsDAO documentsdao = new DocumentsDAO();
		return documentsdao.findAll();
	}
	
	public List getDocumentsByEmployeeID(String employeeID){
		DocumentsDAO documentsdao = new DocumentsDAO();
		return documentsdao.findByEmployeeId(employeeID);
	}
	
	public List getDocumentsByStudentID(String studentID){
		DocumentsDAO documentsdao = new DocumentsDAO();
		return documentsdao.findByStudentId(studentID);
	}
	
	public Student getStudentByStudentID(String studentID){
		StudentDAO studentdao = new StudentDAO();
		return studentdao.findById(studentID);
	}
	
	public Employee getEmployeeByEmployeeID(String employeeID){
		EmployeeDAO employeedao = new EmployeeDAO();
		return employeedao.findById(employeeID);
	}
	
	public void repairedOver(String documentsID){
		DocumentsDAO documentsdao = new DocumentsDAO();
		Documents documents;
		Session session;
		session = HibernateSessionFactory.getSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		documents = documentsdao.findById(documentsID);
		if(documents.getDocumentsState().equals("������"))
		    documents.setDocumentsState("��ȷ��");
		session.merge(documents);
		tx.commit();
		session.close();
	}
}
