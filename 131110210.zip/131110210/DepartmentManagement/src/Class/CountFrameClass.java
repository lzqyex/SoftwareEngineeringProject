package Class;

import java.util.List;
import java.util.Vector;

import org.hibernate.Session;

import model.Documents;
import model.Employee;
import dao.DocumentsDAO;
import dao.EmployeeDAO;
import factory.HibernateSessionFactory;

public class CountFrameClass {

	public List getAllEmployee(){
		EmployeeDAO employeedao = new EmployeeDAO();
		return employeedao.findAll();
	}

	public void countMessage(Vector vector) {
		DocumentsDAO documentsdao = new DocumentsDAO();
		List list = documentsdao.findByEmployeeId(vector.get(0));
		int REPAIRED_OVER = 0;
		int NEED_CONFIRM = 0;
		
		for(int i = 0; i < list.size(); i++){
			if(((Documents)list.get(i)).getDocumentsState().equals("�����"))
				REPAIRED_OVER++;
			if(((Documents)list.get(i)).getDocumentsState().equals("��ȷ��"))
				NEED_CONFIRM++;
		}
		
		vector.add(REPAIRED_OVER);
		vector.add(NEED_CONFIRM);
	}
	
	public void deleteEmployee(String employeeID){
		EmployeeDAO employeedao = new EmployeeDAO();
		Employee employee;
		Session session;
		session = HibernateSessionFactory.getSession();
		org.hibernate.Transaction tx = session.beginTransaction();
		employee = employeedao.findById(employeeID);
		session.delete(employee);
		tx.commit();
		session.close();
	}
	
}
