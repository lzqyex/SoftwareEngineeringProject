package model;

/**
 * Documents entity. @author MyEclipse Persistence Tools
 */

public class Documents implements java.io.Serializable {

	// Fields

	private String documentsId;
	private String documentsState;
	private String studentId;
	private String employeeId;
	private String documentsMessage;

	// Constructors

	/** default constructor */
	public Documents() {
	}

	/** minimal constructor */
	public Documents(String documentsId, String documentsState,
			String studentId, String documentsMessage) {
		this.documentsId = documentsId;
		this.documentsState = documentsState;
		this.studentId = studentId;
		this.documentsMessage = documentsMessage;
	}

	/** full constructor */
	public Documents(String documentsId, String documentsState,
			String studentId, String employeeId, String documentsMessage) {
		this.documentsId = documentsId;
		this.documentsState = documentsState;
		this.studentId = studentId;
		this.employeeId = employeeId;
		this.documentsMessage = documentsMessage;
	}

	// Property accessors

	public String getDocumentsId() {
		return this.documentsId;
	}

	public void setDocumentsId(String documentsId) {
		this.documentsId = documentsId;
	}

	public String getDocumentsState() {
		return this.documentsState;
	}

	public void setDocumentsState(String documentsState) {
		this.documentsState = documentsState;
	}

	public String getStudentId() {
		return this.studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getEmployeeId() {
		return this.employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getDocumentsMessage() {
		return this.documentsMessage;
	}

	public void setDocumentsMessage(String documentsMessage) {
		this.documentsMessage = documentsMessage;
	}

}