/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50624
Source Host           : localhost:3306
Source Database       : departmentdb

Target Server Type    : MYSQL
Target Server Version : 50624
File Encoding         : 65001

Date: 2015-05-28 18:04:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `documents`
-- ----------------------------
DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents` (
  `documentsID` varchar(20) NOT NULL,
  `documentsState` varchar(20) NOT NULL,
  `studentID` varchar(20) NOT NULL,
  `employeeID` varchar(20) DEFAULT NULL,
  `documentsMessage` varchar(50) NOT NULL,
  PRIMARY KEY (`documentsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of documents
-- ----------------------------
INSERT INTO `documents` VALUES ('150527001', '完成', '1001', '3', '窗帘');
INSERT INTO `documents` VALUES ('150527002', '待确认', '1002', '2', '玻璃');
INSERT INTO `documents` VALUES ('150527003', '待确认', '1003', '4', '门');

-- ----------------------------
-- Table structure for `employee`
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `employeeID` varchar(20) NOT NULL,
  `employeeName` varchar(20) NOT NULL,
  `employeePhone` varchar(20) NOT NULL,
  `key` varchar(20) NOT NULL,
  PRIMARY KEY (`employeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of employee
-- ----------------------------
INSERT INTO `employee` VALUES ('1', '张三', '110', '1');
INSERT INTO `employee` VALUES ('2', '李四', '111', '2');
INSERT INTO `employee` VALUES ('3', '王五', '112', '3');
INSERT INTO `employee` VALUES ('4', '刘六', '113', '4');

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `studentID` varchar(20) NOT NULL,
  `studentName` varchar(20) NOT NULL,
  `studentPhone` varchar(20) NOT NULL,
  `studentSex` varchar(5) NOT NULL,
  `key` varchar(20) NOT NULL,
  PRIMARY KEY (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1001', '暴森焱', '131110201', '男', '1001');
INSERT INTO `student` VALUES ('1002', '蔡天力', '131110202', '男', '1002');
INSERT INTO `student` VALUES ('1003', '陈家星', '131110203', '男', '1003');
INSERT INTO `student` VALUES ('1004', '高一鸣', '131110204', '男', '1004');
INSERT INTO `student` VALUES ('1005', '葛成', '131110205', '男', '1005');
INSERT INTO `student` VALUES ('1006', '郭睿', '131110206', '男', '1006');
INSERT INTO `student` VALUES ('1007', '侯晓豪', '131110207', '男', '1007');
INSERT INTO `student` VALUES ('1008', '胡根', '131110208', '男', '1008');
INSERT INTO `student` VALUES ('1009', '姜瑞福', '131110209', '男', '1009');
